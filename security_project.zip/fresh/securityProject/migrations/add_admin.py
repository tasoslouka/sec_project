from app import db, User, app

# Ensure the app context is active for database operations
with app.app_context():
    # Admin details
    username = "Tasos"  # Replace with the desired admin username
    email = "tasos.louka@gmail.com"  # Replace with the desired admin email
    password = "Tasos1234!"  # Replace with the desired admin password

    # Check if the admin already exists
    existing_user = User.query.filter_by(email=email).first()
    if existing_user:
        print(f"Admin with email '{email}' already exists.")
    else:
        # Create a new admin user
        new_admin = User(username=username, email=email, role='admin')
        new_admin.set_password(password)
        db.session.add(new_admin)
        db.session.commit()
        print(f"Admin '{username}' added successfully.")
