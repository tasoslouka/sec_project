import os
import re
import ssl
from datetime import timedelta
from flask import Flask, render_template, request, redirect, url_for, flash, session, make_response
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from werkzeug.security import generate_password_hash, check_password_hash
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SECRET_KEY'] = os.getenv('FLASK_SECRET_KEY', 'your_default_secret_key')
app.config['SESSION_PERMANENT'] = False  # Session expires on browser close
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(minutes=5)
db = SQLAlchemy(app)
migrate = Migrate(app, db)

# Models
class User(db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(50), nullable=False, default='customer')

    def set_password(self, password):
        self.password = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password, password)

    def __repr__(self):
        return f'<User {self.username}>'

class Product(db.Model):
    __tablename__ = 'product'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    description = db.Column(db.String(200), nullable=False)
    price = db.Column(db.Float, nullable=False)
    stock = db.Column(db.Integer, nullable=False)

    def __repr__(self):
        return f'<Product {self.name}>'

class Card(db.Model):
    __tablename__ = 'card'
    id = db.Column(db.Integer, primary_key=True)
    number = db.Column(db.String(16), nullable=False)
    date = db.Column(db.String(5), nullable=False)  # Format MM/YY
    cvv = db.Column(db.String(3), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

    def __repr__(self):
        return f'<Card {self.number} for User ID {self.user_id}>'

# Prevent caching by adding no-store headers
@app.after_request
def add_header(response):
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, post-check=0, pre-check=0, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "-1"
    return response

# Routes
@app.route('/')
def index():
    if 'role' in session:
        if session['role'] == 'admin':
            return redirect(url_for('admin_dashboard'))
        elif session['role'] == 'customer':
            return render_template('customer_index.html', username=session.get('username'))
    welcome_note = "Welcome to MyApp! Explore our products and services."
    return render_template('base.html', username=session.get('username'), welcome_note=welcome_note)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        role = request.form['role']

        # Check if the username or email already exists
        if User.query.filter_by(username=username).first():
            flash('Username already taken. Please choose a different one.', 'warning')
            return redirect(url_for('register'))

        if User.query.filter_by(email=email).first():
            flash('Email already exists!', 'warning')
            return redirect(url_for('register'))

        # Create the new user
        new_user = User(username=username, email=email, role=role)
        new_user.set_password(password)
        db.session.add(new_user)
        db.session.commit()

        flash('Registration successful!', 'success')
        return redirect(url_for('index'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email).first()

        if user and user.check_password(password):
            session['user_id'] = user.id
            session['username'] = user.username
            session['role'] = user.role
            flash('Login successful!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Invalid email or password!', 'danger')

    return render_template('login.html')

@app.route('/admin_dashboard')
def admin_dashboard():
    if session.get('role') != 'admin':
        flash('Unauthorized access', 'danger')
        return redirect(url_for('index'))
    return render_template('admin_index.html', username=session.get('username'))

@app.route('/create_admin', methods=['POST'])
def create_admin():
    if session.get('role') != 'admin':
        flash('Unauthorized access', 'danger')
        return redirect(url_for('index'))

    username = request.form['username']
    email = request.form['email']
    password = request.form['password']

    if User.query.filter_by(username=username).first():
        flash('Username already taken. Please choose a different one.', 'danger')
        return redirect(url_for('admin_dashboard'))

    if User.query.filter_by(email=email).first():
        flash('An admin with this email already exists.', 'danger')
        return redirect(url_for('admin_dashboard'))

    new_admin = User(username=username, email=email, role='admin')
    new_admin.set_password(password)
    db.session.add(new_admin)
    db.session.commit()

    flash('New admin created successfully!', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/add_product', methods=['POST'])
def add_product():
    if session.get('role') != 'admin':
        flash('Unauthorized access', 'danger')
        return redirect(url_for('index'))

    name = request.form['name']
    description = request.form['description']
    price = request.form['price']
    stock = request.form['stock']

    new_product = Product(name=name, description=description, price=price, stock=stock)
    db.session.add(new_product)
    db.session.commit()
    flash('Product added successfully!', 'success')

    return redirect(url_for('admin_dashboard'))

@app.route('/product_list')
def product_list():
    products = Product.query.all()
    return render_template('product_list.html', products=products)

@app.route('/checkout', methods=['GET', 'POST'])
def checkout():
    if request.method == 'POST':
        flash('Purchase completed successfully!', 'success')
        return redirect(url_for('index'))
    return render_template('checkout.html')

@app.route('/payment', methods=['GET', 'POST'])
def payment():
    if 'user_id' not in session:
        flash("Please log in to proceed with payment.", "warning")
        return redirect(url_for('login'))

    user_id = session['user_id']
    product_id = request.args.get('product_id', type=int)
    quantity = request.args.get('quantity', type=int, default=1)

    product = Product.query.get(product_id)
    if not product:
        flash('Product not found.', 'danger')
        return redirect(url_for('product_list'))

    if product.stock < quantity:
        flash(f'Sorry, only {product.stock} item(s) available for {product.name}.', 'warning')
        return redirect(url_for('product_list'))

    saved_cards = Card.query.filter_by(user_id=user_id).all()
    total_price = product.price * quantity

    if request.method == 'POST':
        selected_card_id = request.form.get('selected_card')

        if selected_card_id and selected_card_id != 'new':
            card = Card.query.get(int(selected_card_id))
            if card and card.user_id == user_id:
                product.stock -= quantity
                db.session.commit()
                flash(f'Payment processed for {quantity} x {product.name} using saved card!', 'success')
                return redirect(url_for('product_list'))
            else:
                flash('Selected card not found.', 'danger')
                return redirect(url_for('payment', product_id=product_id, quantity=quantity))
        else:
            number = request.form.get('number')
            date = request.form.get('date')
            cvv = request.form.get('cvv')

            if not number or not re.match(r'^\d{16}$', number):
                flash("Card number must be exactly 16 digits.", "danger")
                return redirect(url_for('payment', product_id=product_id, quantity=quantity))
            if not date or not re.match(r'^\d{2}/\d{2}$', date):
                flash("Expiry date must be in MM/YY format.", "danger")
                return redirect(url_for('payment', product_id=product_id, quantity=quantity))
            if not cvv or not re.match(r'^\d{3}$', cvv):
                flash("CVV must be exactly 3 digits.", "danger")
                return redirect(url_for('payment', product_id=product_id, quantity=quantity))

            new_card = Card(number=number, date=date, cvv=cvv, user_id=user_id)
            db.session.add(new_card)
            product.stock -= quantity
            db.session.commit()

            flash(f'Payment processed for {quantity} x {product.name} and card details saved!', 'success')
            return redirect(url_for('product_list'))

    return render_template('payment.html', saved_cards=saved_cards, product=product, quantity=quantity, total_price=total_price)

@app.route('/logout')
def logout():
    session.clear()
    flash('You have successfully logged out!', 'success')
    return redirect(url_for('index'))

# Enforce HTTPS
@app.before_request
def enforce_https():
    if not request.is_secure:
        url = request.url.replace("http://", "https://", 1)
        return redirect(url, code=301)

# Run the application with SSL
if __name__ == '__main__':
    with app.app_context():
        db.create_all()

    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(certfile='certs/cert.pem', keyfile='certs/key.pem')

    app.run(host='0.0.0.0', port=443, ssl_context=context)
