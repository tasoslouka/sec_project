from app import db, User, Product, app

with app.app_context():
    db.drop_all()
    db.create_all()

    # Sample products
    products = [
        Product(name='Laptop', description='High performance laptop', price=999.99, stock=10),
        Product(name='Smartphone', description='Latest model smartphone', price=499.99, stock=20),
    ]

    db.session.add_all(products)
    db.session.commit()
