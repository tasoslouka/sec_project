from app import db, User, Product, app

# Use the application context
with app.app_context():
    # Clear the existing data (if you want to start fresh)
    db.drop_all()
    db.create_all()

    # Sample users
    users = [

    ]

    # Sample products
    products = [
        Product(name='Laptop', description='High performance laptop', price=999.99, stock=10),
        Product(name='Smartphone', description='Latest model smartphone', price=499.99, stock=20),
    ]

    # Add users and products to the session
    db.session.add_all(users)
    db.session.add_all(products)

    try:
        db.session.commit()  # Commit the session
    except Exception as e:
        print("Error:", e)
        db.session.rollback()  # Rollback in case of error


