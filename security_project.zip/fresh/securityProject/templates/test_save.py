from app import db, Card, app

with app.app_context():
    db.create_all()  # Ensure tables are created
    card = Card(number="4444333322221111", date="12/26", cvv="456")
    db.session.add(card)
    db.session.commit()
    print("Card saved:", Card.query.all())
